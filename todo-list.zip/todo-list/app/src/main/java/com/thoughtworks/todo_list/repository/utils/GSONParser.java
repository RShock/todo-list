package com.thoughtworks.todo_list.repository.utils;

import com.google.gson.Gson;

public class GSONParser {
    public static Gson gsonParser = new Gson();
}
