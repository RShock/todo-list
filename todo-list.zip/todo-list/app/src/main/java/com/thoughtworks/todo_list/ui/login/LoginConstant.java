package com.thoughtworks.todo_list.ui.login;

public class LoginConstant {
    private static final String LOG_TAG = "LoginActivity";
}
