package com.thoughtworks.todo_list.repository;

public class UserConstant {
    public static final String USER_LOG_TAG = "USER";
}
